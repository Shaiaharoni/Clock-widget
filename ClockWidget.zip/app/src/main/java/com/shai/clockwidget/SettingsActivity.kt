package com.shai.clockwidget

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

class SettingsActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var mode = Prefs.MODE_SYSTEM
    private var color = Color.BLACK
    private var transparency = 60
    private var textMode = Prefs.TEXT_AUTO
    private var textColor = Color.WHITE

    private lateinit var radioSystem: RadioButton
    private lateinit var radioCustom: RadioButton
    private lateinit var customBox: View
    private lateinit var hue: SeekBar
    private lateinit var brightness: SeekBar
    private lateinit var transpBar: SeekBar
    private lateinit var transpValue: TextView
    private lateinit var preview: TextView
    private lateinit var locStatus: TextView
    private val swatchViews = mutableListOf<Pair<View, Int>>()
    private val textSwatchViews = mutableListOf<Pair<View, Int>>()
    private lateinit var textCustom: RadioButton
    private lateinit var textSwatchBox: View

    private val textPresets = listOf(
        0xFFFFFFFF.toInt(), 0xFFFFF4E8.toInt(), 0xFFD3D1C7.toInt(), 0xFF1A1A1A.toInt(),
        0xFFFAC775.toInt(), 0xFFB5D4F4.toInt(), 0xFF9FE1CB.toInt(), 0xFFF4C0D1.toInt()
    )

    private val presets = listOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF2C2C2A.toInt(), 0xFF0C447C.toInt(),
        0xFF3C3489.toInt(), 0xFF712B13.toInt(), 0xFF085041.toInt(), 0xFF993556.toInt()
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        widgetId = intent?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))

        val s = Prefs.style(this, widgetId.takeIf { it != AppWidgetManager.INVALID_APPWIDGET_ID })
        mode = s.mode
        color = s.color
        transparency = s.transparency
        textMode = s.textMode
        textColor = s.textColor

        radioSystem = findViewById(R.id.mode_system)
        radioCustom = findViewById(R.id.mode_custom)
        customBox = findViewById(R.id.custom_box)
        hue = findViewById(R.id.hue)
        brightness = findViewById(R.id.brightness)
        transpBar = findViewById(R.id.transparency)
        transpValue = findViewById(R.id.transp_value)
        preview = findViewById(R.id.preview)
        locStatus = findViewById(R.id.loc_status)

        buildSwatches()

        textCustom = findViewById(R.id.text_custom)
        textSwatchBox = findViewById(R.id.text_swatch_box)
        buildTextSwatches()
        if (textMode == Prefs.TEXT_CUSTOM) textCustom.isChecked = true
        else findViewById<RadioButton>(R.id.text_auto).isChecked = true
        findViewById<RadioGroup>(R.id.text_mode_group).setOnCheckedChangeListener { _, checked ->
            textMode = if (checked == R.id.text_custom) Prefs.TEXT_CUSTOM else Prefs.TEXT_AUTO
            refreshUi()
        }

        if (mode == Prefs.MODE_SYSTEM) radioSystem.isChecked = true else radioCustom.isChecked = true
        findViewById<RadioGroup>(R.id.mode_group).setOnCheckedChangeListener { _, checked ->
            mode = if (checked == R.id.mode_system) Prefs.MODE_SYSTEM else Prefs.MODE_CUSTOM
            refreshUi()
        }

        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hue.progress = hsv[0].roundToInt()
        brightness.progress = (hsv[2] * 100).roundToInt()
        val colorListener = SimpleSeek { fromUser ->
            if (fromUser) {
                color = Color.HSVToColor(floatArrayOf(hue.progress.toFloat(), 0.7f, brightness.progress / 100f))
                selectCustom()
                refreshUi()
            }
        }
        hue.setOnSeekBarChangeListener(colorListener)
        brightness.setOnSeekBarChangeListener(colorListener)

        transpBar.progress = transparency
        transpBar.setOnSeekBarChangeListener(SimpleSeek {
            transparency = transpBar.progress
            refreshUi()
        })

        findViewById<Button>(R.id.loc_button).setOnClickListener { requestLocation() }
        findViewById<Button>(R.id.save_button).setOnClickListener { save() }

        updateLocStatus()
        if (Prefs.location(this) == null) requestLocation()
        refreshUi()
    }

    private fun buildSwatches() {
        val box = findViewById<LinearLayout>(R.id.swatches)
        val d = resources.displayMetrics.density
        presets.forEach { c ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt()).apply {
                marginEnd = (10 * d).toInt()
            }
            v.setOnClickListener {
                color = c
                selectCustom()
                refreshUi()
            }
            box.addView(v)
            swatchViews.add(Pair(v, c))
        }
    }

    private fun buildTextSwatches() {
        val box = findViewById<LinearLayout>(R.id.text_swatches)
        val d = resources.displayMetrics.density
        textPresets.forEach { c ->
            val v = View(this)
            v.layoutParams = LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt()).apply {
                marginEnd = (10 * d).toInt()
            }
            v.setOnClickListener {
                textColor = c
                if (!textCustom.isChecked) textCustom.isChecked = true
                textMode = Prefs.TEXT_CUSTOM
                refreshUi()
            }
            box.addView(v)
            textSwatchViews.add(Pair(v, c))
        }
    }

    private fun selectCustom() {
        if (!radioCustom.isChecked) radioCustom.isChecked = true
        mode = Prefs.MODE_CUSTOM
    }

    private fun refreshUi() {
        val d = resources.displayMetrics.density
        val system = mode == Prefs.MODE_SYSTEM
        val base = if (system) getColor(R.color.sys_bg) else color
        val a = (100 - transparency) * 255 / 100

        preview.background = GradientDrawable().apply {
            cornerRadius = 20 * d
            setColor((a shl 24) or (base and 0x00FFFFFF))
        }
        preview.setTextColor(
            when {
                textMode == Prefs.TEXT_CUSTOM -> textColor
                system -> getColor(R.color.sys_text)
                WidgetRenderer.useDarkText(color, transparency) -> 0xFF1A1A1A.toInt()
                else -> Color.WHITE
            }
        )
        transpValue.text = "$transparency%"
        customBox.alpha = if (system) 0.4f else 1f

        val current = color
        val currentText = textColor
        val customText = textMode == Prefs.TEXT_CUSTOM
        textSwatchBox.alpha = if (customText) 1f else 0.4f
        textSwatchViews.forEach { (v, c) ->
            val selected = customText && c == currentText
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(((if (selected) 3 else 1) * d).toInt(), if (selected) 0xFF378ADD.toInt() else 0x55888888)
            }
        }

        swatchViews.forEach { (v, c) ->
            val selected = !system && c == current
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c)
                setStroke(((if (selected) 3 else 1) * d).toInt(), if (selected) 0xFF378ADD.toInt() else 0x55888888)
            }
        }
    }

    // ---------- Location ----------

    private fun requestLocation() {
        if (LocationHelper.hasPermission(this)) fetchLocation()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_LOC) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) fetchLocation()
        else locStatus.setText(R.string.loc_denied)
    }

    @SuppressLint("MissingPermission")
    private fun fetchLocation() {
        val lm = getSystemService(LocationManager::class.java) ?: return fallbackLocation()
        val enabled = try { lm.getProviders(true) } catch (e: Exception) { emptyList<String>() }
        val provider = listOf(LocationManager.NETWORK_PROVIDER, "fused", LocationManager.GPS_PROVIDER)
            .firstOrNull { it in enabled }
            ?: return fallbackLocation()

        locStatus.setText(R.string.loc_searching)
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(provider, null, mainExecutor) { loc ->
                    if (loc != null) onLocation(loc) else fallbackLocation()
                }
            } else {
                @Suppress("DEPRECATION")
                lm.requestSingleUpdate(provider, object : LocationListener {
                    override fun onLocationChanged(location: Location) = onLocation(location)
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(p: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(p: String) {}
                    override fun onProviderDisabled(p: String) {}
                }, Looper.getMainLooper())
            }
        } catch (e: Exception) {
            fallbackLocation()
        }
    }

    private fun fallbackLocation() {
        val l = LocationHelper.lastKnown(this)
        if (l != null) onLocation(l) else locStatus.setText(R.string.loc_failed)
    }

    private fun onLocation(l: Location) {
        Prefs.saveLocation(this, l.latitude, l.longitude)
        locStatus.setText(R.string.loc_saved)
        val app = applicationContext
        Thread {
            WeatherRepository.refresh(app, force = true)
            WidgetRenderer.updateAll(app)
            runOnUiThread { if (!isFinishing) updateLocStatus() }
        }.start()
    }

    private fun updateLocStatus() {
        if (Prefs.location(this) == null) {
            locStatus.setText(R.string.loc_none)
            return
        }
        val w = WeatherRepository.load(this)
        locStatus.text = getString(R.string.loc_saved) + (w?.let { " · ${it.temp.roundToInt()}°" } ?: "")
    }

    // ---------- Save ----------

    private fun save() {
        val style = Prefs.Style(mode, color, transparency, textMode, textColor)
        val mgr = AppWidgetManager.getInstance(this)
        if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
            Prefs.saveStyle(this, widgetId, style)
            WidgetRenderer.update(this, mgr, widgetId)
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        } else {
            Prefs.saveStyle(this, null, style)
            WidgetRenderer.allIds(this).forEach { Prefs.saveStyle(this, it, style) }
            WidgetRenderer.updateAll(this)
            Toast.makeText(this, R.string.saved_all, Toast.LENGTH_SHORT).show()
        }
        val app = applicationContext
        Thread { if (WeatherRepository.refresh(app)) WidgetRenderer.updateAll(app) }.start()
        finish()
    }

    private class SimpleSeek(val onChange: (fromUser: Boolean) -> Unit) : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) = onChange(fromUser)
        override fun onStartTrackingTouch(seekBar: SeekBar) {}
        override fun onStopTrackingTouch(seekBar: SeekBar) {}
    }

    companion object {
        private const val REQ_LOC = 10
    }
}
