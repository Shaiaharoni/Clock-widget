package com.shai.clockwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract

object Intents {
    private const val FLAGS = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Opens Xiaomi's clock app, or the default clock app if it isn't found. */
    fun clock(ctx: Context): PendingIntent {
        val i = ctx.packageManager.getLaunchIntentForPackage("com.android.deskclock")
            ?: Intent(AlarmClock.ACTION_SHOW_ALARMS)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, -1, i, FLAGS)
    }

    fun calendar(ctx: Context): PendingIntent {
        val builder = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
        ContentUris.appendId(builder, System.currentTimeMillis())
        val i = Intent(Intent.ACTION_VIEW, builder.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, -2, i, FLAGS)
    }

    fun settings(ctx: Context, widgetId: Int): PendingIntent {
        val i = Intent(ctx, SettingsActivity::class.java)
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        return PendingIntent.getActivity(ctx, widgetId, i, FLAGS)
    }
}
