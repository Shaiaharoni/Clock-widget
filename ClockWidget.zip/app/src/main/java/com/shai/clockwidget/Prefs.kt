package com.shai.clockwidget

import android.content.Context
import android.graphics.Color

object Prefs {
    const val MODE_SYSTEM = 0
    const val MODE_CUSTOM = 1
    const val TEXT_AUTO = 0
    const val TEXT_CUSTOM = 1

    data class Style(
        val mode: Int,
        val color: Int,
        val transparency: Int,
        val textMode: Int = TEXT_AUTO,
        val textColor: Int = Color.WHITE
    )

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)

    /** id == null means the default style used for new widgets. */
    fun style(ctx: Context, id: Int?): Style {
        val p = prefs(ctx)
        val def = Style(
            p.getInt("mode_default", MODE_SYSTEM),
            p.getInt("color_default", Color.BLACK),
            p.getInt("transp_default", 60),
            p.getInt("tmode_default", TEXT_AUTO),
            p.getInt("tcolor_default", Color.WHITE)
        )
        if (id == null) return def
        return Style(
            p.getInt("mode_$id", def.mode),
            p.getInt("color_$id", def.color),
            p.getInt("transp_$id", def.transparency),
            p.getInt("tmode_$id", def.textMode),
            p.getInt("tcolor_$id", def.textColor)
        )
    }

    fun saveStyle(ctx: Context, id: Int?, s: Style) {
        val k = id?.toString() ?: "default"
        prefs(ctx).edit()
            .putInt("mode_$k", s.mode)
            .putInt("color_$k", s.color)
            .putInt("transp_$k", s.transparency)
            .putInt("tmode_$k", s.textMode)
            .putInt("tcolor_$k", s.textColor)
            .apply()
    }

    fun delete(ctx: Context, id: Int) {
        prefs(ctx).edit().remove("mode_$id").remove("color_$id").remove("transp_$id")
            .remove("tmode_$id").remove("tcolor_$id").apply()
    }

    fun saveLocation(ctx: Context, lat: Double, lon: Double) {
        prefs(ctx).edit().putString("lat", lat.toString()).putString("lon", lon.toString()).apply()
    }

    fun location(ctx: Context): Pair<Double, Double>? {
        val p = prefs(ctx)
        val lat = p.getString("lat", null)?.toDoubleOrNull() ?: return null
        val lon = p.getString("lon", null)?.toDoubleOrNull() ?: return null
        return Pair(lat, lon)
    }
}
