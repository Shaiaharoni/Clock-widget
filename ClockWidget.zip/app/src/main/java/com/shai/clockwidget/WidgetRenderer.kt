package com.shai.clockwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.text.format.DateFormat
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import kotlin.math.roundToInt

object WidgetRenderer {
    private val providers = listOf(
        ClockWidgetSmall::class.java,
        ClockWidgetMedium::class.java,
        ClockWidgetLarge::class.java
    )

    fun allIds(ctx: Context): IntArray {
        val mgr = AppWidgetManager.getInstance(ctx)
        return providers.flatMap { mgr.getAppWidgetIds(ComponentName(ctx, it)).toList() }.toIntArray()
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        allIds(ctx).forEach { update(ctx, mgr, it) }
    }

    /** True when text on this background should be dark instead of white. */
    fun useDarkText(color: Int, transparency: Int): Boolean {
        val alpha = (100 - transparency) / 100.0
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return alpha > 0.4 && lum > 0.6
    }

    fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val style = Prefs.style(ctx, id)
        val system = style.mode == Prefs.MODE_SYSTEM
        val weather = WeatherRepository.load(ctx)

        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH).let { if (it > 0) it else 250 }
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT).let { if (it > 0) it else 110 }

        val rv = RemoteViews(ctx.packageName, if (system) R.layout.widget_system else R.layout.widget_custom)

        // Background: color (custom mode only) and transparency (both modes)
        val alpha = ((100 - style.transparency) * 255 / 100).coerceIn(0, 255)
        rv.setInt(R.id.bg, "setImageAlpha", alpha)

        var text2 = 0xDDFFFFFF.toInt()
        var lineColor = 0xFFFAC775.toInt()
        if (!system) {
            rv.setInt(R.id.bg, "setColorFilter", style.color)
            var text1 = Color.WHITE
            if (useDarkText(style.color, style.transparency)) {
                text1 = 0xFF1A1A1A.toInt()
                text2 = 0xCC1A1A1A.toInt()
                lineColor = 0xFFBA7517.toInt()
            }
            rv.setTextColor(R.id.time, text1)
            rv.setTextColor(R.id.temp, text1)
            rv.setTextColor(R.id.date, text2)
            rv.setTextColor(R.id.range, text2)
        }

        // Date in the system language
        val locale = ctx.resources.configuration.locales[0]
        val datePattern = DateFormat.getBestDateTimePattern(locale, "EEEEdMMMM")
        rv.setCharSequence(R.id.date, "setFormat12Hour", datePattern)
        rv.setCharSequence(R.id.date, "setFormat24Hour", datePattern)

        // Responsive sizing
        val upcoming = weather?.upcoming()
        val showWeather = wDp >= 170
        val showDate = hDp >= 64
        val wantGraph = hDp >= 150 && upcoming != null && upcoming.second.size >= 2
        val topH = if (wantGraph) hDp * 0.5f else hDp.toFloat()
        val dateH = if (showDate) 22f else 0f
        val timeSp = minOf(
            (wDp - 24f - (if (showWeather) 95f else 0f)) / 2.7f,
            (topH - 24f - dateH) / 1.2f
        ).coerceIn(18f, 110f)

        rv.setTextViewTextSize(R.id.time, TypedValue.COMPLEX_UNIT_SP, timeSp)
        rv.setViewVisibility(R.id.date, if (showDate) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.weather_box, if (showWeather) View.VISIBLE else View.GONE)

        // Weather
        if (weather != null) {
            rv.setTextViewText(R.id.temp, "${weather.temp.roundToInt()}°")
            rv.setTextViewText(R.id.icon, WeatherRepository.icon(weather.code, weather.isDay))
            rv.setTextViewText(R.id.range, "${weather.min.roundToInt()}° / ${weather.max.roundToInt()}°")
            rv.setViewVisibility(R.id.range, View.VISIBLE)
        } else {
            rv.setTextViewText(R.id.temp, "--°")
            rv.setTextViewText(R.id.icon, "")
            rv.setViewVisibility(R.id.range, View.GONE)
        }

        // Hourly graph (drawn white in system mode; the layout tints it with the system accent)
        val graphH = hDp - 24f - timeSp * 1.2f - dateH - 6f
        if (wantGraph && upcoming != null && graphH >= 40f) {
            val bmp = GraphRenderer.render(
                ctx, upcoming.first, upcoming.second, wDp - 24f, graphH,
                if (system) Color.WHITE else lineColor,
                if (system) Color.WHITE else text2
            )
            rv.setImageViewBitmap(R.id.graph, bmp)
            rv.setViewVisibility(R.id.graph, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.graph, View.GONE)
        }

        // Taps: time -> clock, date -> calendar, weather/graph -> settings
        rv.setOnClickPendingIntent(R.id.time, Intents.clock(ctx))
        rv.setOnClickPendingIntent(R.id.date, Intents.calendar(ctx))
        rv.setOnClickPendingIntent(R.id.weather_box, Intents.settings(ctx, id))
        rv.setOnClickPendingIntent(R.id.graph, Intents.settings(ctx, id))

        mgr.updateAppWidget(id, rv)
    }
}
