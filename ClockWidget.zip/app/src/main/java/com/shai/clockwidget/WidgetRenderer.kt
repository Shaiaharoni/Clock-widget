package com.shai.clockwidget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.text.format.DateFormat
import android.os.Build
import android.os.Bundle
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import java.util.Locale
import kotlin.math.roundToInt

object WidgetRenderer {
    private val providers = listOf(
        ClockWidgetSmall::class.java,
        ClockWidgetMedium::class.java,
        ClockWidgetLarge::class.java
    )

    private val cells = intArrayOf(R.id.cell_0, R.id.cell_1, R.id.cell_2, R.id.cell_3, R.id.cell_4, R.id.cell_5)
    private val hTemps = intArrayOf(R.id.h_temp_0, R.id.h_temp_1, R.id.h_temp_2, R.id.h_temp_3, R.id.h_temp_4, R.id.h_temp_5)
    private val hIcons = intArrayOf(R.id.h_icon_0, R.id.h_icon_1, R.id.h_icon_2, R.id.h_icon_3, R.id.h_icon_4, R.id.h_icon_5)
    private val hHours = intArrayOf(R.id.h_hour_0, R.id.h_hour_1, R.id.h_hour_2, R.id.h_hour_3, R.id.h_hour_4, R.id.h_hour_5)

    fun allIds(ctx: Context): IntArray {
        val mgr = AppWidgetManager.getInstance(ctx)
        return providers.flatMap { mgr.getAppWidgetIds(ComponentName(ctx, it)).toList() }.toIntArray()
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        allIds(ctx).forEach { update(ctx, mgr, it) }
    }

    /** True when text on this background should be dark instead of white. */
    fun useDarkText(color: Int, transparency: Int): Boolean {
        val alpha = (100 - transparency) / 100.0
        val lum = (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255.0
        return alpha > 0.4 && lum > 0.6
    }

    /** Widget size in dp for portrait. Uses the exact sizes list on Android 12+. */
    private fun sizeDp(opts: Bundle): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 31) {
            @Suppress("DEPRECATION")
            val sizes = opts.getParcelableArrayList<SizeF>(AppWidgetManager.OPTION_APPWIDGET_SIZES)
            val s = sizes?.maxByOrNull { it.height }
            if (s != null && s.width > 0 && s.height > 0) return Pair(s.width.toInt(), s.height.toInt())
        }
        val w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH)
        val h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT)
        return Pair(if (w > 0) w else 250, if (h > 0) h else 180)
    }

    fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
        val style = Prefs.style(ctx, id)
        val system = style.mode == Prefs.MODE_SYSTEM
        val weather = WeatherRepository.load(ctx)

        val (wDp, hDp) = sizeDp(mgr.getAppWidgetOptions(id))

        val rv = RemoteViews(ctx.packageName, if (system) R.layout.widget_system else R.layout.widget_custom)

        // Background: color (custom mode only) and transparency (both modes)
        val alpha = ((100 - style.transparency) * 255 / 100).coerceIn(0, 255)
        rv.setInt(R.id.bg, "setImageAlpha", alpha)

        if (!system) {
            rv.setInt(R.id.bg, "setColorFilter", style.color)
            val dark = useDarkText(style.color, style.transparency)
            val text1 = if (dark) 0xFF1A1A1A.toInt() else Color.WHITE
            val text2 = if (dark) 0xDD1A1A1A.toInt() else 0xEEFFFFFF.toInt()
            val text3 = if (dark) 0xAA1A1A1A.toInt() else 0xCCFFFFFF.toInt()
            rv.setTextColor(R.id.time, text1)
            rv.setTextColor(R.id.temp, text1)
            rv.setTextColor(R.id.date, text2)
            rv.setTextColor(R.id.range, text2)
            hTemps.forEach { rv.setTextColor(it, text1) }
            hHours.forEach { rv.setTextColor(it, text3) }
            hIcons.forEach { rv.setInt(it, "setColorFilter", text1) }
            rv.setInt(R.id.icon, "setColorFilter", text1)
            rv.setInt(R.id.divider, "setColorFilter", text1)
        }

        // Date in the system language
        val locale = ctx.resources.configuration.locales[0]
        val datePattern = DateFormat.getBestDateTimePattern(locale, "EEEEdMMMM")
        rv.setCharSequence(R.id.date, "setFormat12Hour", datePattern)
        rv.setCharSequence(R.id.date, "setFormat24Hour", datePattern)

        // Responsive sizing
        val columns = ((wDp - 24) / 52).coerceIn(3, 6)
        val hours = weather?.upcoming(columns) ?: emptyList()
        val showWeather = wDp >= 170
        val showDate = hDp >= 64
        val showHourly = hDp >= 140 && hours.size >= 2
        // The clock size itself is automatic: it grows to fill the space left in the widget.
        rv.setViewVisibility(R.id.date, if (showDate) View.VISIBLE else View.GONE)
        rv.setViewVisibility(R.id.weather_box, if (showWeather) View.VISIBLE else View.GONE)

        // Current weather
        if (weather != null) {
            rv.setTextViewText(R.id.temp, "${weather.temp.roundToInt()}°")
            rv.setImageViewResource(R.id.icon, WeatherRepository.iconRes(weather.code, weather.isDay))
            rv.setViewVisibility(R.id.icon, View.VISIBLE)
            rv.setTextViewText(R.id.range, "${weather.min.roundToInt()}° / ${weather.max.roundToInt()}°")
            rv.setViewVisibility(R.id.range, View.VISIBLE)
        } else {
            rv.setTextViewText(R.id.temp, "--°")
            rv.setViewVisibility(R.id.icon, View.GONE)
            rv.setViewVisibility(R.id.range, View.GONE)
        }

        // Hourly forecast row: temperature, condition icon, hour
        if (showHourly) {
            for (i in cells.indices) {
                val h = hours.getOrNull(i)
                if (h == null) {
                    rv.setViewVisibility(cells[i], View.GONE)
                    continue
                }
                rv.setViewVisibility(cells[i], View.VISIBLE)
                rv.setTextViewText(hTemps[i], "${h.temp.roundToInt()}°")
                rv.setImageViewResource(hIcons[i], WeatherRepository.iconRes(h.code, h.isDay))
                rv.setTextViewText(hHours[i], String.format(Locale.US, "%02d:00", h.hour))
            }
            rv.setViewVisibility(R.id.hourly, View.VISIBLE)
        } else {
            rv.setViewVisibility(R.id.hourly, View.GONE)
        }

        // Taps: time -> clock, date -> calendar, weather/forecast -> settings
        rv.setOnClickPendingIntent(R.id.time, Intents.clock(ctx))
        rv.setOnClickPendingIntent(R.id.date, Intents.calendar(ctx))
        rv.setOnClickPendingIntent(R.id.weather_box, Intents.settings(ctx, id))
        rv.setOnClickPendingIntent(R.id.hourly, Intents.settings(ctx, id))

        mgr.updateAppWidget(id, rv)
    }
}
