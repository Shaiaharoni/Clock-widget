package com.shai.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.sqrt

object GraphRenderer {
    private const val MAX_PIXELS = 180_000f   // keeps the bitmap small enough for widgets

    fun render(
        ctx: Context,
        startHour: Int,
        temps: List<Double>,
        widthDp: Float,
        heightDp: Float,
        lineColor: Int,
        labelColor: Int
    ): Bitmap {
        var s = ctx.resources.displayMetrics.density
        val pixels = widthDp * s * heightDp * s
        if (pixels > MAX_PIXELS) s *= sqrt(MAX_PIXELS / pixels)

        val bw = (widthDp * s).toInt().coerceAtLeast(2)
        val bh = (heightDp * s).toInt().coerceAtLeast(2)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)

        val n = temps.size
        val pad = 18f * s
        val top = 17f * s
        val bottom = bh - 18f * s
        val mn = temps.min() - 1.0
        val mx = temps.max() + 1.0

        fun x(i: Int): Float = pad + i * (bw - 2 * pad) / (n - 1)
        fun y(v: Double): Float = (bottom - (v - mn) / (mx - mn) * (bottom - top)).toFloat()

        val line = Path()
        temps.forEachIndexed { i, v -> if (i == 0) line.moveTo(x(i), y(v)) else line.lineTo(x(i), y(v)) }

        val fill = Path(line)
        fill.lineTo(x(n - 1), bottom)
        fill.lineTo(x(0), bottom)
        fill.close()
        c.drawPath(fill, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = lineColor
            alpha = 50
            style = Paint.Style.FILL
        })

        c.drawPath(line, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = lineColor
            style = Paint.Style.STROKE
            strokeWidth = 2.5f * s
            strokeJoin = Paint.Join.ROUND
            strokeCap = Paint.Cap.ROUND
        })

        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = lineColor }
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = labelColor
            textSize = 11f * s
            textAlign = Paint.Align.CENTER
        }
        val step = if (n > 8) 3 else 2
        for (i in 0 until n step step) {
            val v = temps[i]
            c.drawCircle(x(i), y(v), 3.5f * s, dot)
            c.drawText("${v.roundToInt()}°", x(i), y(v) - 6f * s, text)
            c.drawText(
                String.format(Locale.US, "%02d:00", (startHour + i) % 24),
                x(i), bh - 4f * s, text
            )
        }
        return bmp
    }
}
