package com.shai.clockwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

data class Weather(
    val temp: Double,
    val code: Int,
    val isDay: Boolean,
    val min: Double,
    val max: Double,
    val startHour: Int,
    val hourly: List<Double>,
    val fetchedAt: Long
) {
    /** Next [count] hours starting from the current hour. Returns (first hour, temps). */
    fun upcoming(count: Int = 12): Pair<Int, List<Double>> {
        val now = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        var off = (now - startHour + 24) % 24
        if (off > hourly.size - 2) off = 0
        return Pair((startHour + off) % 24, hourly.drop(off).take(count))
    }
}

object WeatherRepository {
    private const val MIN_INTERVAL = 25 * 60_000L

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences("weather", Context.MODE_PRIVATE)

    fun load(ctx: Context): Weather? {
        val s = prefs(ctx).getString("data", null) ?: return null
        return try {
            val o = JSONObject(s)
            val arr = o.getJSONArray("hourly")
            Weather(
                o.getDouble("temp"), o.getInt("code"), o.getBoolean("isDay"),
                o.getDouble("min"), o.getDouble("max"), o.getInt("start"),
                (0 until arr.length()).map { arr.getDouble(it) },
                o.getLong("fetched")
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Downloads fresh weather. Returns true if new data was saved. Safe to call often. */
    @Synchronized
    fun refresh(ctx: Context, force: Boolean = false): Boolean {
        val last = load(ctx)?.fetchedAt ?: 0L
        if (!force && System.currentTimeMillis() - last < MIN_INTERVAL) return false

        LocationHelper.lastKnown(ctx)?.let { Prefs.saveLocation(ctx, it.latitude, it.longitude) }
        val (lat, lon) = Prefs.location(ctx) ?: return false

        return try {
            val w = parse(download(lat, lon))
            save(ctx, w)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun download(lat: Double, lon: Double): String {
        val url = URL(
            "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,weather_code,is_day" +
                "&hourly=temperature_2m" +
                "&daily=temperature_2m_max,temperature_2m_min" +
                "&timezone=auto&forecast_days=2"
        )
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 10_000
        return try {
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(text: String): Weather {
        val o = JSONObject(text)
        val cur = o.getJSONObject("current")
        val curTime = cur.getString("time")          // e.g. 2026-10-30T08:15
        val hourPrefix = curTime.substring(0, 13)     // 2026-10-30T08
        val hourly = o.getJSONObject("hourly")
        val times = hourly.getJSONArray("time")
        val temps = hourly.getJSONArray("temperature_2m")
        var start = 0
        for (i in 0 until times.length()) {
            if (times.getString(i).startsWith(hourPrefix)) { start = i; break }
        }
        val list = (start until minOf(start + 24, temps.length()))
            .map { temps.optDouble(it, Double.NaN) }
            .filter { !it.isNaN() }
        val daily = o.getJSONObject("daily")
        return Weather(
            temp = cur.getDouble("temperature_2m"),
            code = cur.getInt("weather_code"),
            isDay = cur.optInt("is_day", 1) == 1,
            min = daily.getJSONArray("temperature_2m_min").getDouble(0),
            max = daily.getJSONArray("temperature_2m_max").getDouble(0),
            startHour = curTime.substring(11, 13).toInt(),
            hourly = list,
            fetchedAt = System.currentTimeMillis()
        )
    }

    private fun save(ctx: Context, w: Weather) {
        val o = JSONObject()
            .put("temp", w.temp).put("code", w.code).put("isDay", w.isDay)
            .put("min", w.min).put("max", w.max).put("start", w.startHour)
            .put("hourly", JSONArray(w.hourly)).put("fetched", w.fetchedAt)
        prefs(ctx).edit().putString("data", o.toString()).apply()
    }

    fun icon(code: Int, isDay: Boolean): String = when (code) {
        0 -> if (isDay) "☀️" else "🌙"
        1, 2 -> if (isDay) "🌤️" else "☁️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌦️"
        85, 86 -> "🌨️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
